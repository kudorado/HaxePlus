#include <AdMobEx.h>
#import <UIKit/UIKit.h>
#import "GoogleMobileAds/GADInterstitialAd.h"
#import <AppTrackingTransparency/AppTrackingTransparency.h>
#import <AdSupport/AdSupport.h>
#import "GoogleMobileAds/GoogleMobileAds.h"
#import "IronSource/IronSource.h"

extern "C"{
    #import "GoogleMobileAds/GADBannerView.h"
}

extern "C" void reportInterstitialEvent (const char* event);
static const char* ADMOB_LEAVING = "LEAVING";
static const char* ADMOB_FAILED = "FAILED";
static const char* ADMOB_CLOSED = "CLOSED";
static const char* ADMOB_DISPLAYING = "DISPLAYING";
static const char* ADMOB_LOADED = "LOADED";
static const char* ADMOB_LOADING = "LOADING";

////////////////////////////////////////////////////////////////////////

static bool _admobexChildDirected = true;

GADRequest *_admobexGetGADRequest(){
    GADRequest *request = [GADRequest request];
    // request.requestConfiguration.testDeviceIdentifiers  @[ @"819596164260f461a1b3be3a3ba4da90" ];
    if(_admobexChildDirected){
        NSLog(@"AdMobEx: enabling COPPA support");
        [request tagForChildDirectedTreatment:YES];
    }
    return request;        
}

////////////////////////////////////////////////////////////////////////
//banner
@interface BannerViewListener : NSObject<GADBannerViewDelegate> {
    // @public
    // GADBannerView *bannerView;
}
@property(nonatomic, strong) GADBannerView *bannerView;

- (id)reInit:(NSString*)ID;
- (id)requestIDFA:(NSString*)BANNER;
- (id)showBanner:(NSString*)shit;
- (id)hideBanner:(NSString*)shit;
- (id)addBannerViewToView:(UIView*)shit;

// - (bool)isReady;

@end

@implementation BannerViewListener

// - (bool)isReady{
// //           NSLog(@"self" + self);
//     return (self.bannerView != nil);
// }


-(id)initWithID: (NSString*)ID {
        //   NSLog(@"banner shit" + kGADAdSizeBanner.width);

    UIWindow* win =  [[UIApplication sharedApplication] keyWindow];
    UIViewController* vc = [win rootViewController];

    // GADAdSize size = GADAdSizeFromCGSize(CGSizeMake(300, 50));
    self.bannerView = [[GADBannerView alloc] initWithAdSize: kGADAdSizeBanner];
    self.bannerView.adUnitID = ID;
    self.bannerView.rootViewController = vc;
    self.bannerView.delegate = self;


    // self.bannerView.translatesAutoresizingMaskIntoConstraints = NO;
    // [vc addSubview:self.bannerView];


    GADRequest *request = _admobexGetGADRequest();
  // Requests test ads on devices you specify. Your test device ID is printed to the console when
  // an ad request is made. GADBannerView automatically returns test ads when running on a
  // simulator.
   [self.bannerView loadRequest:request];

    NSLog(@"banner shit load");
            

    // self.bannerView.adUnitID = @;
  
    // self.bannerView = [[GADBannerView alloc]
    // self.bannerView.rootViewController = vc;
    // initWithAdSize:kGADAdSizeBanner];
    // [self.bannerView loadRequest:[GADRequest request]];
    // self.bannerView.delegate = self;
    // self.bannerView.rootViewController = vc;
    // [self addBannerViewToView:self.bannerView];

}

- (id)addBannerViewToView:(UIView *)shit {

}

- (id)requestIDFA:(NSString*)BANNER {
  [ATTrackingManager requestTrackingAuthorizationWithCompletionHandler:^(ATTrackingManagerAuthorizationStatus status) {
    // Tracking authorization completed. Start loading ads here.
    // [self initWithID];
    [self initWithID:BANNER];
    // [[InterstitialListener alloc] initWithID:interstitialID];
  }];
}

- (id) showBanner :(NSString*) shit{
        NSLog(@"show banner 91");
    if(self.bannerView){
        // [self addBannerViewToView: self.bannerView];
        self.bannerView.hidden = false;
        NSLog(@"show banner 94");
  
    }
}
- (id) hideBanner :(NSString*) shit{
    NSLog(@"hide banner 97");
    if(self.bannerView){
        NSLog(@"show banner 99");
        self.bannerView.hidden = true;
    }
}
    // self.bannerView = [[GADBannerView alloc]
    // self.bannerView.adUnitID = ID;
    // self.bannerView.rootViewController = self;
    // initWithAdSize:kGADAdSizeBanner];
    // [self.bannerView loadRequest:[GADRequest request]];

    // [self addBannerViewToView: bannerView];
// }

// }
- (void)bannerViewDidReceiveAd:(GADBannerView *)bannerView {
  NSLog(@"bannerViewDidReceiveAd");
}

- (void)bannerView:(GADBannerView *)bannerView didFailToReceiveAdWithError:(NSError *)error {
  NSLog(@"bannerView:didFailToReceiveAdWithError: %@", [error localizedDescription]);

}

- (void)bannerViewDidRecordImpression:(GADBannerView *)bannerView {
  NSLog(@"bannerViewDidRecordImpression");
}

- (void)bannerViewWillPresentScreen:(GADBannerView *)bannerView {
  NSLog(@"bannerViewWillPresentScreen");
}

- (void)bannerViewWillDismissScreen:(GADBannerView *)bannerView {
  NSLog(@"bannerViewWillDismissScreen");
}

- (void)bannerViewDidDismissScreen:(GADBannerView *)bannerView {
  NSLog(@"bannerViewDidDismissScreen");
}
@end


@interface InterstitialListener : NSObject <ISInterstitialDelegate> {
    // @public
    // GADInterstitialAd  *interstitial;
}
@property(nonatomic, strong) GADInterstitialAd *interstitial;
- (id)initWithID:(NSString*)ID;
- (id)show:(NSString*)shit;
- (bool)isReady;
- (id)requestIDFA:(NSString*)INTERSTITIAL;
- (id)initWithID:(NSString*)ID;

@end

@implementation InterstitialListener
- (id)initWithID:(NSString*)ID {

    self = [super init];
    if(!self) return nil;

    // self.interstitial = [[GADInterstitialAd alloc] initWithAdUnitID:ID];
    // self.interstitial.delegate = self;

    // GADRequest *request = _admobexGetGADRequest();  // request.testDevices = @[kGADSimulatorID ];
    // // [ad performSelector:@selector(loadRequest:) withObject:request afterDelay:1];
    // [GADInterstitialAd loadWithAdUnitID:ID
    //                           request:request
    //                 completionHandler:^(GADInterstitialAd *ad, NSError *error) {
    // if (error) {
    //   NSLog(@"Failed to load interstitial ad with error: %@", [error localizedDescription]);
    //   return;
    // }


    [IronSource setInterstitialDelegate:self];
    [IronSource initWithAppKey:@"ffe4a791"];
    [IronSource loadInterstitial];

    [ISIntegrationHelper validateIntegration];

    NSLog(@"IS Start Loading Interstitial");


        // self.interstitial = ad;
        // self.interstitial.fullScreenContentDelegate = self;

    // }];
    // reportInterstitialEvent(ADMOB_LOADING);
    return self;
}
-(id)reInit: (NSString*)ID {
    self = [super init];
    if(!self) return nil;

    [IronSource loadInterstitial];

    NSLog(@"IS reload Interstitial");
    return self;

}


- (bool)isReady{
    NSLog(@"shit 192");

    if([IronSource hasInterstitial])
    return true;


    return false;
    // return false;
    // return (self.interstitial != nil && self.interstitial);
}

- (id)show:(NSString*) shit{
    NSLog(@"show interstitial shityeah 218");

    UIWindow* win =  [[UIApplication sharedApplication] keyWindow];
    UIViewController* vc = [win rootViewController];
    [IronSource showInterstitialWithViewController: vc];

    // [IronSource loadInterstitial];


    // if (self.interstitial){
    // NSLog(@"show interstitial shit 220");

    //     // [interstitial presentFromRootViewController:self];
    // // [interstitial presentFromRootViewController:[[[UIApplication sharedApplication] keyWindow] rootViewController]];
    //   UIWindow* win =  [[UIApplication sharedApplication] keyWindow];
    //   UIViewController* vc = [win rootViewController];
    //   [self.interstitial presentFromRootViewController:vc];
    // }
}

//Invoked when Interstitial Ad is ready to be shown after load function was //called.
-(void)interstitialDidLoad {

}
// Called if showing the Interstitial for the user has failed.
//You can learn about the reason by examining the ‘error’ value
-(void)interstitialDidFailToShowWithError:(NSError *)error 
{
      NSLog(@"Failed to show interstitial ad with error: %@", [error localizedDescription]);

}
//Called each time the end user has clicked on the Interstitial ad, for supported networks only 
-(void)didClickInterstitial {

}
//Called each time the Interstitial window is about to close
-(void)interstitialDidClose {
    NSLog(@"IS Interstitial closed!");
    // [IronSource interstitial]
    // [IronSource loadInterstitial];
}
//Called each time the Interstitial window is about to open
-(void)interstitialDidOpen {

}
//Invoked when there is no Interstitial Ad available after calling load //function. @param error - will contain the failure code and description.
-(void)interstitialDidFailToLoadWithError:(NSError *)error {
      NSLog(@"Failed to load interstitial ad with error: %@", [error localizedDescription]);

}

//Invoked right before the Interstitial screen is about to open. 
-(void)interstitialDidShow {
    NSLog(@"IS Interstitial loaded!");
}

- (void)ad:(nonnull id<GADFullScreenPresentingAd>)ad
didFailToPresentFullScreenContentWithError:(nonnull NSError *)error {
    NSLog(@"Ad did fail to present full screen content.");
}

/// Tells the delegate that the ad presented full screen content.
- (void)adDidPresentFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad {
    NSLog(@"Ad did present full screen content.");
}

/// Tells the delegate that the ad dismissed full screen content.
- (void)adDidDismissFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad {
   NSLog(@"Ad did dismiss full screen content.");
}
- (id)requestIDFA:(NSString*)INTERSTITIAL {
    [ATTrackingManager requestTrackingAuthorizationWithCompletionHandler:^(ATTrackingManagerAuthorizationStatus status) {
    // Tracking authorization completed. Start loading ads here.
    [self initWithID: INTERSTITIAL];

    // [[InterstitialListener alloc] :interstitialID];
  }];
}
/// Called when an interstitial ad request failed.
// - (void)interstitial:(GADInterstitial *)ad didFailToReceiveAdWithError:(GADRequestError *)error {
//     NSLog(@"interstitialDidFailToReceiveAdWithError: %@", [error localizedDescription]);
//     reportInterstitialEvent(ADMOB_FAILED);
// }

// /// Called just before presenting an interstitial.
// - (void)interstitialWillPresentScreen:(GADInterstitialAd *)ad {
//     NSLog(@"interstitialWillPself.interstitialresentScreen");
//     reportInterstitialEvent(ADMOB_DISPLAYING);
// }

// /// Called before the interstitial is to be animated off the screen.
// - (void)interstitialWillDismissScreen:(GADInterstitial *)ad {
//     NSLog(@"interstitialWillDismissScreen");
// }

// /// Called just after dismissing an interstitial and it has animated off the screen.
// - (void)interstitialDidDismissScreen:(GADInterstitial *)ad {
//     NSLog(@"interstitialDidDismissScreen");
//     reportInterstitialEvent(ADMOB_CLOSED);
// }

// /// Called just before the application will background or terminate because the user clicked on an
// /// ad that will launch another application (such as the App Store).
// - (void)interstitialWillLeaveApplication:(GADInterstitial *)ad {
//     NSLog(@"interstitialWillLeaveApplication");
//     reportInterstitialEvent(ADMOB_LEAVING);
// }
// - (void)requestIDFA {
//   [ATTrackingManager requestTrackingAuthorizationWithCompletionHandler:^(ATTrackingManagerAuthorizationStatus status) {
//     // Tracking authorization completed. Start loading ads here.
//     // [self loadAd];
//   }];

@end

namespace admobex {
	
    // static GADBannerView *bannerView;
	static InterstitialListener *interstitialListener;
    static BannerViewListener *bannerViewListener;
    static bool bottom;

    static NSString *interstitialID;

	UIViewController *root;
    
	void init(const char *__BannerID, const char *__InterstitialID, const char *gravityMode, bool testingAds, bool tagForChildDirectedTreatment){

        root = [[[UIApplication sharedApplication] keyWindow] rootViewController];
        // NSString *GMODE = [NSString stringWithUTF8String:gravityMode];
        // NSString *bannerID = [NSString stringWithUTF8String:__BannerID];
        interstitialID = [NSString stringWithUTF8String:__InterstitialID];
        _admobexChildDirected = tagForChildDirectedTreatment;
        NSLog(@"request test id 307");
        // GADMobileAds.sharedInstance.requestConfiguration.testDeviceIdentifiers =@[ @"2077ef9a63d2b398840261c8221a0c9b" ];





        // if(testingAds){

        // bannerID       = @"ca-app-pub-3940256099942544/2934735716"; // test id babe
        // interstitialID = @"ca-app-pub-3940256099942544/4411468910"; //test id shit

        // interstitialID = @"ca-app-pub-3879807251614613/8823817552"; // ADMOB GENERIC TESTING INTERSTITIAL
        // bannerID = @"ca-app-pub-3879807251614613/5009723294"; // ADMOB GENERIC TESTING BANNER
        // }
        // GADMobileAds.sharedInstance.requestConfiguration.testDeviceIdentifiers = @[ @"819596164260f461a1b3be3a3ba4da90" ];
        // BANNER
        // bottom=![GMODE isEqualToString:@"TOP"];

        // if( [UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationLandscapeLeft ||
        //     [UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationLandscapeRight )
        // {
        //     bannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeBanner];
        // }else{
        //     bannerView = [[GADBannerView alloc] initWithAdSize:kGADAdSizeBanner];
        // }

		// bannerView.adUnitID = bannerID;
		// bannerView.rootViewController = root;


        
        // GADRequest *request = _admobexGetGADRequest();
		// request.testDevices = @[ kGADSimulatorID ];
		// [bannerView loadRequest:request];
        // [root.view addSubview:bannerView];
        // bannerView.hidden=true;
        // // THOSE THREE LINES ARE FOR SETTING THE BANNER BOTTOM ALIGNED
        // if(bottom){
        //     CGRect frame = bannerView.frame;
        //     frame.origin.y = root.view.bounds.size.height - frame.size.height;
        //     bannerView.frame = frame;
        // }

    // INTERSTITIAL
        // interstitialListener = [[InterstitialListener alloc] initWithID:interstitialID];
        NSLog(@"init is babe!");

        [IronSource shouldTrackReachability:YES];


        interstitialListener = [InterstitialListener alloc];
        [interstitialListener  requestIDFA:interstitialID];



        // [interstitialListener initWithID:interstitialID]; 
        //  [self initWithID:INTERSTITIAL];
        // bannerViewListener = [BannerViewListener alloc];
        // [bannerViewListener requestIDFA:bannerID];

    }
    
    void showBanner(){
        NSLog(@"showBanner 311!");
        // if(bannerViewListener==nil) return;
        //     NSLog(@"showBanner 324");

        //  if([bannerViewListener showBanner:@"shit"]);
        //         NSLog(@"showBanner 327");
        //     if(bannerViewListener.bannerView == nil)return; 
            
        //                     NSLog(@"showBanner 334");

        //     bannerViewListener.bannerView.hidden=false;
        // // }

        //             NSLog(@"showBanner 318");

    }
    
    void hideBanner(){
        //         NSLog(@"hideBanner 319");
        // if(bannerViewListener==nil) return;


        // [bannerViewListener hideBanner:@"shit"];

        //         NSLog(@"hideBanner 343");

        // // if([bannerViewListener isReady]){
        //     bannerViewListener.bannerView.hidden=true;
        // }
            NSLog(@"hideBanner 324");

    }
    
	void refreshBanner(){
        NSLog(@"refreshBanner 326");

         if(bannerViewListener==nil) return;

        // if(bannerViewListener.bannerView){
		// [bannerViewListener.bannerView loadRequest:_admobexGetGADRequest()];
        // }
        NSLog(@"refreshBanner 333");

	}

    bool showInterstitial(){
        NSLog(@"showInterstitial 328");

        if(interstitialListener==nil) {
            return false;
        }

        if(![interstitialListener isReady])
        {
            return false;
        }
            NSLog(@"showInterstitial 384");

        [interstitialListener show:@"shit"];


        // interstitialListener = [[InterstitialListener alloc] initWithID:interstitialID];
        //     NSLog(@"showInterstitial 388");



        return true;
    }


}
