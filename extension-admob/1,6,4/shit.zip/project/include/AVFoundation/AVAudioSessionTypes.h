/*
	File:           AVAudioSessionTypes.h
	Framework:      AVFoundation
	
	Copyright 2020 Apple Inc. All rights reserved.
*/

#if __has_include(<AVFAudio/AVAudioSessionTypes.h>)
#import <AVFAudio/AVAudioSessionTypes.h>
#endif
